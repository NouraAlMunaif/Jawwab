//
//  InstructionsViewController.swift
//  Jawwab
//
//  Created by atheer on 1/28/19.
//  Copyright © 2019 atheer. All rights reserved.
//

import UIKit
import ARKit
import Firebase

class InstructionsViewController: UIViewController , PopupDelegate {
    func transfer(_ popup: Popup) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let Question1ViewController = storyBoard.instantiateViewController(withIdentifier: "mainView") as! Question1ViewController
        
        self.present(Question1ViewController, animated: true, completion: nil)
    }
    
 
    
    
    let userId = UserDefaults.standard.object(forKey: "userId") as? String
    var ref: DatabaseReference!
    
    func handelbacgroung(_ popup: Popup) {
        visualEffectView.alpha = 0
    }
    
    
    
    @IBOutlet weak var sceneView: ARSCNView!
    let view2 = Popup()
    
    let visualEffectView: UIVisualEffectView = {
        let blurEffect = UIBlurEffect(style: .light)
        let view = UIVisualEffectView(effect: blurEffect)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        view.addSubview(visualEffectView)
        visualEffectView.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        visualEffectView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        visualEffectView.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
        visualEffectView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        
        visualEffectView.alpha = 1
        
        view2.delegate = self
        view.addSubview(view2)
        view2.translatesAutoresizingMaskIntoConstraints = false
        view2.layer.cornerRadius = 15
        view2.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        view2.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        view2.heightAnchor.constraint(equalToConstant: view.frame.width - 64).isActive = true
        view2.widthAnchor.constraint(equalToConstant: view.frame.width - 64).isActive = true
        
        
        view2.showSuccessMessage = true
        
        view2.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        view2.alpha = 0
        
        UIView.animate(withDuration: 0.5) {
            self.visualEffectView.alpha = 1
            self.view2.alpha = 1
            self.view2.transform = CGAffineTransform.identity
        }
        
        
        
        func setupScene() {
            let scene = SCNScene()
            sceneView.scene = scene
        }
        
        func setupConfiguration() {
            let configuration = ARWorldTrackingConfiguration()
            sceneView.session.run(configuration)
        }
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let configuration = ARWorldTrackingConfiguration()
        sceneView.session.run(configuration)
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }
    
    func animateIn() {
        
        
        view2.transform = CGAffineTransform.init(scaleX: 1.3, y: 1.3)
        view2.alpha = 0
        
        UIView.animate(withDuration: 0.4) {
            self.visualEffectView.effect = self.visualEffectView.effect
            self.view2.alpha = 1
            self.view2.transform = CGAffineTransform.identity
        }}
    
    func addBox() {
        // var  result = sceneView.hitTest(point: CGPoint, types: ARHitTestResult.ResultType)
        
        let box = SCNBox(width: 0.1, height: 0.1, length: 0.1, chamferRadius: 0)
        
        let boxNode = SCNNode()
        boxNode.geometry = box
        boxNode.position = SCNVector3(1, 1, 1)
        
        // ARHitRestResult
        //let result = sceneView!.hitTest((0,0), .existingPlaneUsingExtent)
        //let anchor = ARAnchor(transform:hit.worldTransform)
        // sceneView.session.add(anchor:anchor)
        
        
        let scene = SCNScene()
        scene.rootNode.addChildNode(boxNode)
        
        sceneView.scene = scene
        
    }
    
}
