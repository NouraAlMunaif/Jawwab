//
//  QMessagesViewController.swift
//  Proximity
//
//  Created by Reema on 27/01/2019.
//  Copyright © 2019 Estimote, Inc. All rights reserved.
//

import UIKit
import AVFoundation
import Firebase
class SuccessMessagesViewController: UIViewController {

    @IBOutlet weak var label: UIImageView!
    
//    @IBOutlet weak var label: UILabel!
    var player: AVAudioPlayer?
    let userId = UserDefaults.standard.object(forKey: "userId") as? String
    var ref: DatabaseReference!
    
    func playSound(fileName: String) {
        
        guard let url = Bundle.main.url(forResource: fileName, withExtension: "mp3") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
            
            
            guard let player = player else { return }
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
        
    }
    
    @IBAction func close(_ sender: Any) {
        
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let Question1ViewController = storyBoard.instantiateViewController(withIdentifier: "mainView") as! Question1ViewController
        
        self.present(Question1ViewController, animated: true, completion: nil)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.label.layer.masksToBounds = true
        self.label.layer.cornerRadius = 15
        // playSound(fileName: "kidsCheering")
        self.updateRewards()
//print("!!!")

    }
    
    func updateRewards(){
        
        ref = Database.database().reference();
        
        
        let userscore = ref.child("users").child(userId!).child("UserScore")
        userscore.observeSingleEvent(of: .value, with: { (snapshot) in
            
            if let score = snapshot.value as? String{
                var score1 = Int(score)
                score1 = score1! + 5;
                print(score1!)
                self.passingScore(score1: score1!)
            }
        })
        
        
    }
    func passingScore(score1: Int){
        ref = Database.database().reference();
         let score2 = String(score1);
        ref.child("users").child(userId!).child("UserScore").setValue(score2)
       
    //rewards.text = score2
        
        
        
    }



}
