//
//  ProfileViewController.swift
//  Jawwab
//
//  Created by Nouf on 2/23/19.
//  Copyright © 2019 atheer. All rights reserved.
//

import UIKit
import Firebase
class ProfileViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    

    
let userId = UserDefaults.standard.object(forKey: "userId") as? String
var ref: DatabaseReference!
    
    @IBOutlet weak var CharName: UILabel!
    @IBOutlet weak var charScore: UILabel!
    @IBOutlet weak var charLevel: UILabel!
    @IBOutlet weak var charImage: UIImageView!
    
 var p = 0
    @IBOutlet weak var tableView: UITableView!
    var scoresArray = [Int]()
    var namesArray = [String]()
    var LeaderboardList = [profile]()
  
  
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       // print("hii")
        // creating scrollbar
       /* let numberOfSections = self.tableView.numberOfSections
        let numberOfRows = self.tableView.numberOfRows(inSection: numberOfSections-1)
        
        let indexPath = IndexPath(row: numberOfRows-1 , section: numberOfSections-1)
        self.tableView.scrollToRow(at: indexPath, at: UITableView.ScrollPosition.middle, animated: true)*/
        
        
      
        
        
        
        
        let nib = UINib(nibName: "TableCell", bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: "TableCell")
        
   
        ref = Database.database().reference();
        let leaderboadInfo = ref.child("users")
        leaderboadInfo.observe(DataEventType.value, with: { (snapshot) in
            
          self.LeaderboardList.removeAll()
            
            for info in snapshot.children.allObjects as! [DataSnapshot]{
           
            let infoObject = info.value as? [String: AnyObject]
            let name = infoObject?["Name"]
            let score = infoObject?["UserScore"]
                
              
                let LeaderboardObject = profile(username: name as! String?, score: score as! String?)
                self.LeaderboardList.append(LeaderboardObject)
             
                
            }
            
           self.tableView.reloadData()
     
    self.LeaderboardList = self.LeaderboardList.sorted{ Int($0.score ?? "7") ?? 7 > Int($1.score ?? "7") ?? 7 }

        })
        

        
///////////////// character image retrieval into the profile////////////////
        ref = Database.database().reference();
        let userGender = ref.child("users").child(userId!).child("Gender")
        userGender.observeSingleEvent(of: .value, with: { (snapshot) in
         let gender = snapshot.value as? Int
            if(gender==1){
      self.charImage.image = UIImage(named:"girl.jpg")
                self.charImage.image = #imageLiteral(resourceName: "girl")}
        if(gender==0){
                self.charImage.image = UIImage(named:"boy.jpg")
            self.charImage.image = #imageLiteral(resourceName: "boy")}
        })
 
/////////// character image retrieval into the profile////////////////
      
   
        
        
        
///////////// character name retrieval into the profile////////////////
        ref = Database.database().reference();
        let userName = ref.child("users").child(userId!).child("Name")
        userName.observeSingleEvent(of: .value, with: { (snapshot) in
            let name = snapshot.value as? String
            self.CharName.text = name
        })
////////////// character name retrieval into the profile////////////////
        
        
        
        
 ////////////// character score retrieval into the profile////////////////
        ref = Database.database().reference();
        let userScore = ref.child("users").child(userId!).child("UserScore")
        userScore.observeSingleEvent(of: .value, with: { (snapshot) in
            let score = snapshot.value as? String
            self.charScore.text = score
             })
 ////////////// character score retrieval into the profile////////////////
        
        
        0
        
        
/////////////////// character level retrieval into the profile ////////////////
        ref = Database.database().reference();
        let userLevel = ref.child("tour").child(userId!).child("level")
        userLevel.observeSingleEvent(of: .value, with: { (snapshot) in
            var level = snapshot.value as? Int
            level = level ?? 0 + 1
            if let level1 = Int(self.charLevel.text!) {
                self.charLevel.text = "\(level1)"
            }
          
        })
////////////// character level retrieval into the profile/////////////////////
 
 
}
    @IBAction func switchTable(_ sender: UISegmentedControl) {
       p = sender.selectedSegmentIndex
        
        if (p==0){
         tableView.reloadData()
            
        }
        
        else{
        }
        
    }
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
        return LeaderboardList.count
        
    }
    

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableCell") as! TableCell
   
    
        
        
        cell.CellInit(Pname: LeaderboardList[indexPath.row].username ?? "u", Pscore : LeaderboardList[indexPath.row].score ?? "s")
        return cell
    }
    
 
    
}


