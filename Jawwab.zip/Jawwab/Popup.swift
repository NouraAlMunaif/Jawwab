//
//  Popup.swift
//  Jawwab
//
//  Created by Nora Almunaif on 25/05/1440 AH.
//  Copyright © 1440 atheer. All rights reserved.
//

import Foundation
import UIKit

protocol PopupDelegate: class {
    func handelbacgroung(_ popup: Popup)
    func transfer(_ popup: Popup)
}

class Popup: UIView {
    
    
    // MARK: - Properties
    
    var delegate: PopupDelegate?
    
    private(set) var bk: Int = 0
    
    var intrCounter = 1
    
    
    // define black plane
    // define each icon in the coner of screen
    
    
    var showSuccessMessage: Bool? {
        didSet {
            guard let success = showSuccessMessage else { return }
            if success {
                notificationLabel.text = "أهلا بك في جوّاب.. لنبدأ الرحلة"
                checkLabel.textColor = UIColor(red: 147/255, green: 227/255, blue: 105/255, alpha: 1)
            } else {
                checkLabel.text = "X"
                notificationLabel.text = "Error"
                checkLabel.textColor = .red
            }
        }
    }
    
    
    
    let checkLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        
        label.font = UIFont.systemFont(ofSize: 96)
        
        return label
    }()
    
    
    
    let notificationLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont(name: "Avenir", size: 16)
        return label
    }()
    
    
    let button: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("التالي", for: .normal)
        button.backgroundColor = UIColor(red:0.90, green:0.59, blue:0.48, alpha:1.0)
        button.setTitleColor(.white, for: .normal)
        button.addTarget(self, action: #selector(nextText), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.layer.cornerRadius = 20
        return button
    }()
    
    let button2: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("تخطي التعليمات", for: .normal)
        button.backgroundColor = .white
        button.setTitleColor(UIColor(red:0.90, green:0.59, blue:0.48, alpha:1.0), for: .normal)
        button.addTarget(self, action: #selector(dismiss), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.layer.cornerRadius = 20
        return button
    }()
    
    
    
    let someImageView: UIImageView = {
        let theImageView = UIImageView()
        theImageView.translatesAutoresizingMaskIntoConstraints = false //You need to call this property so the image is added to your view
        return theImageView
    }()
    // MARK: - Init
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .white
        
        
        
        //        addSubview(checkLabel)
        //        checkLabel.centerYAnchor.constraint(equalTo: centerYAnchor, constant: -28).isActive = true
        //        checkLabel.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        
        addSubview(someImageView)
        someImageView.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        someImageView.centerYAnchor.constraint(equalTo: centerYAnchor, constant: -60).isActive = true
        
        addSubview(notificationLabel)
        notificationLabel.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        notificationLabel.topAnchor.constraint(equalTo: someImageView.bottomAnchor, constant: 10).isActive = true
        
        
        addSubview(button)
        button.heightAnchor.constraint(equalToConstant: 50).isActive = true
        button.leftAnchor.constraint(equalTo: leftAnchor, constant: 12).isActive = true
        button.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -60).isActive = true
        button.rightAnchor.constraint(equalTo: rightAnchor, constant: -12).isActive = true
        
        addSubview(button2)
        button2.heightAnchor.constraint(equalToConstant: 50).isActive = true
        button2.leftAnchor.constraint(equalTo: leftAnchor, constant: 12).isActive = true
        button2.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -10).isActive = true
        button2.topAnchor.constraint(equalTo: button.bottomAnchor, constant: 10).isActive = true
        button2.rightAnchor.constraint(equalTo: rightAnchor, constant: -12).isActive = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Selectors
    
    
    @objc func dismiss(){
        self.removeFromSuperview()
        bk += 1
        delegate?.transfer(self)
        delegate?.handelbacgroung(self)
    }
    
    
    @objc func nextText(){
        var instructions = ["lol"]
        var images = ["x"]
        let w1 = "تجول في المتحف واجمع النقاط بالإجابة على التحديات"
        let w2 = "خارطة التجول توضح مكان التحديات"
        let w3 = "النقاط تزداد بإجابتك بشكل صحيح"
        let w4 = "هنا يظهر اللاعبين المتصدرين ونقاطهم"
        let w5 = "بإمكانك إنهاء الرحلة من هنا"
        let w6 = "التقط صورة في أي وقت"
        
        let x1 = "map.png"
        let x2 = "points.png"
        let x3 = "leaderboard.png"
        let x4 = "signout-1.png"
        let x5 = "camera.png"
        
        
        instructions.append(w1)
        instructions.append(w2)
        instructions.append(w3)
        instructions.append(w4)
        instructions.append(w5)
        instructions.append(w6)
        
        images.append(x1)
        images.append(x2)
        images.append(x3)
        images.append(x4)
        images.append(x5)
        
        
        
        if(intrCounter < 7){
            
            notificationLabel.text = instructions[intrCounter]
            intrCounter = intrCounter + 1
            
            
            
            switch intrCounter {
                
            case 2:
                
                print("Some other character")
            //                    someImageView.image = UIImage(named:  "map.png")
            case 3:
                someImageView.image = UIImage(named:  "map.png")
            case 4:
                someImageView.image = UIImage(named:  "points.png")
            case 5:
                someImageView.image = UIImage(named:  "leaderboard.png")
            case 6:
                someImageView.image = UIImage(named:  "signout-1.png")
            case 7:
                someImageView.image = UIImage(named:  "camera.png")
                button.setTitle( "ابدأ الرحلة", for: .normal)
                
             
            default:
                print("Some other character")
            }
            
            
        }
            
            
        else{
            
            if ( intrCounter == 7 ){
                
                self.removeFromSuperview()
                bk += 1
                delegate?.transfer(self)
                delegate?.handelbacgroung(self)
                
                
                
            }
        }
        
        
    }
    
}
