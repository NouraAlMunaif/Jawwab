//
//  ViewController.swift
//  Jawwab
//
//  Created by atheer on 1/22/19.
//  Copyright © 2019 atheer. All rights reserved.
//

import UIKit
import Firebase
import GameplayKit


// For generating random numbers

extension Int {
    static func random(min: Int, max: Int) -> Int {
        precondition(min <= max)
        let randomizer = GKRandomSource.sharedRandom()
        return min + randomizer.nextInt(upperBound: max - min + 1)
    }
}


class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var emptyname: UILabel!
    
    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var school: UITextField!
    
    @IBOutlet weak var female: UIButton!
    
    @IBOutlet weak var male: UIButton!
    
   
    
    var gender = 0
    
 
    var ref: DatabaseReference!
    

    @IBOutlet weak var btn: UIButton!
  

    override func viewDidLoad() {
        super.viewDidLoad()
        ref = Database.database().reference()
        
        emptyname.isHidden = true
        
        let tap:UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(DismissKey))
        
        view.addGestureRecognizer(tap)
    }
    
    @objc func DismissKey(){
        view.endEditing(true)
    }

    
    @IBAction func femaleClicked(_ sender: Any) {
        
        female.setBackgroundImage(UIImage(named: "GirlSelected"), for: UIControl.State.normal)
        male.setBackgroundImage(UIImage(named: "boy_ntselected"), for: UIControl.State.normal)
        
        gender = 1
        
    }
    
    
    @IBAction func maleClicked(_ sender: Any) {
        
        male.setBackgroundImage(UIImage(named: "BoySelected"), for: UIControl.State.normal)
        female.setBackgroundImage(UIImage(named: "GirlNtSelected"), for: UIControl.State.normal)
        
        gender = 0
    }

    
    // When btn is clicked add these
    @IBAction func btnClicked(_ sender: Any) {
        
      //  let randomInt = Int.random(min: 1, max: 1000)
        //   let randomInt = Int.random(min: 1, max: 1000)
        print("enter click")
    
        if(name.text?.isEmpty == true){
            emptyname.isHidden = false
            emptyname.text = "X لا تترك خانة الاسم فارغة"
            
        }
    
        
        if(name.text?.isEmpty == false){
            // to be tested
    
            // getting the current date of registration
            let date = Date()
            let formatter = DateFormatter()
            formatter.dateFormat = "dd/MM/yyyy"
            let resultdate = formatter.string(from: date)
            print(resultdate)
            print("!!!!")
            // getting the current time for registration
            let date1 = Date()
            let calendar = Calendar.current
            let hour = calendar.component(.hour, from: date1)
            let minutes = calendar.component(.minute, from: date1)
            let time = String(hour)  + ":" + String(minutes)
            print(time)
            
            ref = Database.database().reference();
            let userID = Database.database().reference().childByAutoId().key
            ref.child("users").child(userID).child("Name").setValue(self.name.text)
            ref.child("users").child(userID).child("School").setValue(self.school.text)
            ref.child("users").child(userID).child("Gender").setValue(gender)
            ref.child("users").child(userID).child("UserScore").setValue("0")
            ref.child("users").child(userID).child("regDate").setValue(resultdate)
            ref.child("users").child(userID).child("regTime").setValue(time)
            
            // Tracking the Tour
            ref.child("tour").child(userID).child("user").setValue(userID)
            ref.child("tour").child(userID).child("q1").setValue(0)
            ref.child("tour").child(userID).child("q2").setValue(0)
            ref.child("tour").child(userID).child("q3").setValue(0)
            ref.child("tour").child(userID).child("q4").setValue(0)
            // Add as much as you need
            ref.child("tour").child(userID).child("current").setValue(0)
            ref.child("tour").child(userID).child("level").setValue(0)
            print("user is tracked")
            
            
            print("user added successfully ")

            
    // session
    UserDefaults.standard.set(userID, forKey:"userId");
    UserDefaults.standard.synchronize();
            

    }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if ( name.text?.isEmpty == true ) {
            return false }
        return true
    }
   
        
    }




