//
//  QuestionViewController.swift
//  Proximity
//
//  Created by Reema on 24/01/2019.
//  Copyright © 2019 Estimote, Inc. All rights reserved.
//

import UIKit
import Firebase
import AVFoundation //kit for the sounds effects
import EstimoteProximitySDK
import SceneKit
import ARKit



class QuestionViewController: UIViewController {
    
    var ref: DatabaseReference!
    var optionsArray = [String]()
    var player: AVAudioPlayer?
    var node: SCNNode!

    @IBOutlet weak var reward: UILabel!
    @IBOutlet weak var sceneView: ARSCNView!
    // storyboard elements
    @IBOutlet weak var Qview: UITextView!
    //options for the question
    @IBOutlet weak var answersView: UIView!
    @IBOutlet weak var opt1: UIButton!
    @IBOutlet weak var opt2: UIButton!
    @IBOutlet weak var opt3: UIButton!
    var questionNum : String?
    let userId = UserDefaults.standard.object(forKey: "userId") as? String
    @IBOutlet weak var label2: UIView!
 //   @IBOutlet weak var label1: UIView!
    var proximityObserver: ProximityObserver!
    
    
    func playSound(fileName: String) {
        
        guard let url = Bundle.main.url(forResource: fileName, withExtension: "mp3") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
            
            
            guard let player = player else { return }
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
        
    }
    
 /*   func updateRewards(){
        
        ref = Database.database().reference();
        
        
        let userscore = ref.child("users").child(userId!).child("UserScore")
        userscore.observeSingleEvent(of: .value, with: { (snapshot) in
            
            if let score = snapshot.value as? String{
                let score1 = Int(score)
                print(score1!)
                self.passingScore(score1: score1!)
            }
        })
        
        
    }
    
    
    func passingScore(score1: Int){
        ref = Database.database().reference();
        let score2 = String(score1);
        ref.child("users").child(userId!).child("UserScore").setValue(score2)
        //let score2 = String(score1);
        reward.text = score2
    }
    */
    
    @IBAction func click1(_ sender: Any) {
        // ref = Database.database().reference();
        if (opt1.titleLabel?.text) != nil {
            let userAnswer=opt1.titleLabel?.text;
            
            if ((userAnswer!.elementsEqual(self.optionsArray[0])) == true)
            {
                solveChallange(q: 3, status: 1)
                setCurrent(q: 3)
                
                label2.removeFromSuperview()
                opt1.removeFromSuperview()
                opt2.removeFromSuperview()
                opt3.removeFromSuperview()
                self.node.removeFromParentNode()

                
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let SuccessMessagesViewController = storyBoard.instantiateViewController(withIdentifier: "QMessage") as! SuccessMessagesViewController
                
                self.present(SuccessMessagesViewController, animated: true, completion: nil)
                
                
                
                
            }
            
            
            
        }
    }
    
    
    @IBAction func click2(_ sender: Any) {
        //  ref = Database.database().reference();
        if (opt2.titleLabel?.text) != nil {
            let userAnswer=opt2.titleLabel?.text;
            
            if ((userAnswer!.elementsEqual(self.optionsArray[0])) == true)
            {
                solveChallange(q: 3, status: 1)
                setCurrent(q: 3)
                
                
                label2.removeFromSuperview()
                opt1.removeFromSuperview()
                opt2.removeFromSuperview()
                opt3.removeFromSuperview()
                self.node.removeFromParentNode()

                
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let SuccessMessagesViewController = storyBoard.instantiateViewController(withIdentifier: "QMessage") as! SuccessMessagesViewController
                
                self.present(SuccessMessagesViewController, animated: true, completion: nil)
                
                
            }
            
            
            
        }
    }
    
    @IBAction func click3(_ sender: Any) {
        //ref = Database.database().reference();
        if (opt3.titleLabel?.text) != nil {
            let userAnswer=opt3.titleLabel?.text;
            
            if ((userAnswer!.elementsEqual(self.optionsArray[0])) == true)
            {
                solveChallange(q: 3, status: 1)
                setCurrent(q: 3)
                
                label2.removeFromSuperview()
                opt1.removeFromSuperview()
                opt2.removeFromSuperview()
                opt3.removeFromSuperview()
                self.node.removeFromParentNode()

                
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let SuccessMessagesViewController = storyBoard.instantiateViewController(withIdentifier: "QMessage") as! SuccessMessagesViewController
                
                self.present(SuccessMessagesViewController, animated: true, completion: nil)
                
                
            }
            
            
            
            
            
        }
        
    }
    
    
    
    override func viewDidLoad(){  DispatchQueue.main.async {
        super.viewDidLoad()
        
        self.playSound(fileName: "popUp")
        self.getNumOfQuestions();
        
        //self.label1.layer.masksToBounds = true
   //     self.label1.layer.cornerRadius = 15
        
        self.label2.layer.masksToBounds = true
        self.label2.layer.cornerRadius = 15
     //   self.updateRewards()
        
   /*     let estimoteCloudCredentials = CloudCredentials(appID: "jawab-test-2m5", appToken: "6ff2355c245c7d7953c64eb5c2a912ba")
        
        self.proximityObserver = ProximityObserver(credentials: estimoteCloudCredentials, onError: { error in
            print("ProximityObserver error: \(error)")
        })
        
        let zone = ProximityZone(tag: "jawab-test-2m5", range: ProximityRange.near)
        
        zone.onExit = { contexts in
            print("Exit from Question view controller")
            
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let Question1ViewController = storyBoard.instantiateViewController(withIdentifier: "mainView") as! Question1ViewController
            
            self.present(Question1ViewController, animated: true, completion: nil)
        }
        
        
        self.proximityObserver.startObserving([zone])
        
        */
        
        }
    }
    
    
    
    func  DisplayQuestionAndanswer(count: String){
        self.questionNum=count;
        
        ref = Database.database().reference();
        let question = self.ref.child("questions").child(count);
        
        question.observe(DataEventType.value, with: { (snapshot) in
            if !snapshot.exists() { return }
            let postDict = snapshot.value as? [String : AnyObject]
            let content = postDict?["content"]
            
            // AR Object
            var text = SCNText(string: content, extrusionDepth: 0.1)
            let material = SCNMaterial()
            material.diffuse.contents = UIColor.black
            text.materials = [material]
            text.font = UIFont(name: "Avenir", size: 10)
            
            self.node = SCNNode()
            self.node.position = SCNVector3(0, 0 , 0)
            self.node.scale = SCNVector3(0.001, 0.001, 0.001)
            self.node.geometry = text
            text = self.node.geometry as! SCNText
            
            let minVec = self.node.boundingBox.min
            let maxVec = self.node.boundingBox.max
            let bound = SCNVector3Make(maxVec.x - minVec.x,
                                       maxVec.y - minVec.y,
                                       maxVec.z - minVec.z);
            self.node.pivot = SCNMatrix4MakeTranslation(bound.x / 2,
                                                        bound.y / 2,
                                                        bound.z / 2)
            
            let image = UIImage(named: "question")
            let planeNode4 = SCNNode(geometry: SCNPlane(width: 15, height: 15))
            planeNode4.geometry?.firstMaterial?.diffuse.contents = image
            planeNode4.position = SCNVector3(bound.x/2 , 18, 0)
            
            let plane = SCNPlane(width:  CGFloat(bound.x + 15),
                                 height: CGFloat(bound.y + 40))
            plane.cornerRadius = 5
            plane.firstMaterial?.diffuse.contents = UIColor.white.withAlphaComponent(0.8)
            
            
            let planeNode = SCNNode(geometry: plane)
            planeNode.position = SCNVector3(CGFloat( minVec.x  ) + CGFloat(bound.x ) / 2 ,
                                            CGFloat( minVec.y ) + CGFloat(bound.y ) / 2,CGFloat(minVec.z - 0.01))
            
            self.node.addChildNode(planeNode)
            self.node.addChildNode(planeNode4)
            planeNode.name = "text"
            let scene = SCNScene()
            self.node.camera = SCNCamera()
            scene.rootNode.addChildNode(self.node)
            
            self.sceneView.scene = scene
        })
        
        
        let answers = self.ref.child("questions").child(count).child("answers");
        answers.observe(DataEventType.value, with: { (snapshot) in
            
            if !snapshot.exists() { return }
            let postDict1 = snapshot.value as? [String : AnyObject]
            let option1 = postDict1?["option1"]
            let option2 = postDict1?["option2"]
            let option3 = postDict1?["option3"]
            
            self.optionsArray.append(option1 as! String)
            self.optionsArray.append(option2 as! String)
            self.optionsArray.append(option3 as! String)
            
            
            let ran1=Int.random(in: 0 ... 2);
            
            var ran2=Int.random(in: 0 ... 2)
            while(ran1==ran2){
                ran2=Int.random(in: 0 ... 2)}
            
            
            var  ran3=Int.random(in: 0 ... 2);
            while(ran3==ran1||ran3==ran2){
                ran3=Int.random(in: 0 ... 2);}
            
            
            self.opt1.setTitle(self.optionsArray[ran1] as String?, for: .normal)
            self.opt2.setTitle(self.optionsArray[ran2] as String?, for: .normal)
            self.opt3.setTitle(self.optionsArray[ran3] as String?, for: .normal)
            
        })
        
    }
    
  
    func  getNumOfQuestions(){
        
        ref = Database.database().reference();
        
        let numberOfquestions = ref.child("questions")
        numberOfquestions.observe(.value, with: { (snapshot: DataSnapshot!) in
            let numberOfquestions1 = Int(snapshot.childrenCount)
            
            let questionNumber = Int.random(in: 1 ... numberOfquestions1)
            let snum = String(questionNumber)
            
            self.DisplayQuestionAndanswer(count: snum)
        })
    }
    
    
    
    
  
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Create a session configuration
        let configuration = ARWorldTrackingConfiguration()
        
        // Run the view's session
        sceneView.session.run(configuration)
    }
    
    
    func initChallange(q: Int){
        ref = Database.database().reference();
        var userId = UserDefaults.standard.object(forKey: "userId") as? String
        // 0 ==> not solved  || 1 ==> solved
        self.ref.child("tour").child(userId!).child("q\(q)").setValue(0)
        
    }
    
    func solveChallange(q: Int, status: Int){
        ref = Database.database().reference();
        var userId = UserDefaults.standard.object(forKey: "userId") as? String
        // 0 ==> not solved  // 1 ==> solved
        self.ref.child("tour").child(userId!).updateChildValues(["q\(q)": status])
        
    }
    
    func setCurrent(q: Int){
        ref = Database.database().reference();
        var userId = UserDefaults.standard.object(forKey: "userId") as? String
        self.ref.child("tour").child(userId!).updateChildValues(["current": q])
        
        
    }
    
}

