import UIKit
import ARKit
import EstimoteProximitySDK
import Firebase
struct Content {
    let title: String
    let subtitle: String
}

@available(iOS 11.0, *)
class Question1ViewController: UIViewController, UICollectionViewDelegateFlowLayout {
    
    var flag: Bool = false
    @IBOutlet weak var rewards: UILabel!
    @IBOutlet weak var sceneView: ARSCNView!
    //   var planeNode4: SCNNode!
    // let userId = UserDefaults.standard.object(forKey: "userId") as? String
    var ref: DatabaseReference!
    var proximityObserverBlueBarry: ProximityObserver!
    var proximityObserver: ProximityObserver!
    var flagCoconut = true
    var flagMint = true
    var flagBlueBerry = true
    var flagIce = true
    var flagCoconut2 = false
    var flagMint2 = false
    var flagBlueBerry2 = false
    var flagIce2 = false
    var QuestionAR = [SCNNode]()
    var nearbyContent = [Content]()
    var arrBeacon = [Bool]()
    let fadeDuration: TimeInterval = 0.3
    let rotateDuration: TimeInterval = 3
    let waitDuration: TimeInterval = 0.5
    let userId = UserDefaults.standard.object(forKey: "userId") as? String
    var temp: Bool = false
    
    lazy var fadeAndSpinAction: SCNAction = {
        return .sequence([
            .fadeIn(duration: fadeDuration),
            .rotateBy(x: 0, y: 0, z: CGFloat.pi * 360 / 180, duration: rotateDuration),
            .wait(duration: waitDuration)
            // .fadeOut(duration: fadeDuration)
            ])
    }()
    
    lazy var fadeAction: SCNAction = {
        return .sequence([
            .fadeOpacity(by: 0.8, duration: fadeDuration),
            .wait(duration: waitDuration),
            //   .fadeOut(duration: fadeDuration)
            ])
    }()
    
    
    func updateRewards(){
        
        ref = Database.database().reference();
        
        
        let userscore = ref.child("users").child(userId!).child("UserScore")
        userscore.observeSingleEvent(of: .value, with: { (snapshot) in
            
            if let score = snapshot.value as? String{
                let score1 = Int(score)
                print(score1!)
                self.passingScore(score1: score1!)
            }
        })
        
        
    }
    
    
    func passingScore(score1: Int){
        ref = Database.database().reference();
        let score2 = String(score1);
        ref.child("users").child(userId!).child("UserScore").setValue(score2)
        //let score2 = String(score1);
        rewards.text = score2
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first as! UITouch
        if(touch.view == self.sceneView){
            print("touch working")
            let viewTouchLocation:CGPoint = touch.location(in: sceneView)
            guard let result = sceneView.hitTest(viewTouchLocation, options: nil).first else {
                return
            }
            
            if (QuestionAR.contains(result.node)) { //to ensure which 3d object was touched
                print("match")
                if self.flagMint2 {
                    self.flagMint = true
                    self.flagMint2 = false
                    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let QuestionViewController = storyBoard.instantiateViewController(withIdentifier: "Questionscene") as! QuestionViewController
                    
                    self.present(QuestionViewController, animated: true, completion: nil)
                    
                }
                if self.flagIce2 {
                    self.flagIce = true
                    self.flagIce2 = false
                    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let QuestViewController = storyBoard.instantiateViewController(withIdentifier: "questScene") as! QuestViewController
                    self.present(QuestViewController, animated: true, completion: nil)
                    
                }
                if self.flagCoconut2 {
                    self.flagCoconut = true
                    self.flagCoconut2 = false
                    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let MarksViewController = storyBoard.instantiateViewController(withIdentifier: "MarksStoryBoard") as! MarksViewController
                    self.present(MarksViewController, animated: true, completion: nil)
                    
                }
                if self.flagBlueBerry2 {
                    self.flagBlueBerry = true
                    self.flagBlueBerry2 = false
                    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let PuzzleViewController = storyBoard.instantiateViewController(withIdentifier: "PuzzleStoryBoard") as! PuzzleViewController
                    
                    self.present(PuzzleViewController, animated: true, completion: nil)
                }
            }
            
        }
        
    }
    
    func displayBeacon() {
        //    for i in arrBeacon {
        //      print("value of array", arrBeacon[i])
        //     }
        
        print("inside displayBeacon 1")
        ref = Database.database().reference();
        let qustions = ref.child("tour").child(userId!)
        qustions.observe(DataEventType.value, with: { (snapshot) in
            
            if !snapshot.exists() { return }
            let getData = snapshot.value as? [String : AnyObject]
            
            let q1 = getData!["q1"] as? Int
            let q2 = getData!["q2"] as? Int
            let q3 = getData!["q3"] as? Int
            let q4 = getData!["q4"] as? Int
            
            if q1==1 {
                self.arrBeacon.append(true)
            }
            else {
                self.arrBeacon.append(false)
            }
            if q2==1 {
                self.arrBeacon.append(true)
            }
            else {
                self.arrBeacon.append(false)
            }
            if q3==1 {
                self.arrBeacon.append(true)
            }
            else {
                self.arrBeacon.append(false)
            }
            if q4==1 {
                self.arrBeacon.append(true)
            }
            else {
                self.arrBeacon.append(false)
            }
            print("inside displayBeacon 2")
            self.temp = true
            
            
            self.Beacon()
        })
        
    }
    
    func Beacon() {
        var i = 0
        while i<arrBeacon.count {
            print(arrBeacon[i])
            i = i + 1
        }
        
        let credentials = CloudCredentials(appID: "jawwab-s-your-own-app-lu3", appToken: "156e99a87189f9a6c4baf33f0268d425")
        
        self.proximityObserver = ProximityObserver(credentials: credentials, onError: { error in
            print("ProximityObserver error: \(error)")
        })
        
        let zoneMint = ProximityZone(tag: "Mint", range: ProximityRange(desiredMeanTriggerDistance: 1.0)!)
        if !self.arrBeacon[2] {
            zoneMint.onEnter = { contexts in
                print (" work!!")
                print ("Mint zone")
                self.flagMint2 = true
                self.flagMint = true
                
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let QuestionViewController = storyBoard.instantiateViewController(withIdentifier: "Questionscene") as! QuestionViewController
                
                self.present(QuestionViewController, animated: true, completion: nil)
                
                //    self.displayQObj()
                /*       let text = SCNText(string: "?", extrusionDepth: 0.1)
                 let material = SCNMaterial()
                 material.diffuse.contents = UIColor.orange
                 text.materials = [material]
                 text.font = UIFont(name: "Avenir", size: 100)
                 
                 let planeNode4 = SCNNode()
                 planeNode4.position = SCNVector3(0, 0 , 0)
                 planeNode4.scale = SCNVector3(0.001, 0.001, 0.001)
                 planeNode4.geometry = text
                 planeNode4.runAction(self.fadeAndSpinAction)
                 self.QuestionAR.append(planeNode4)
                 let scene = SCNScene()
                 planeNode4.camera = SCNCamera()
                 self.sceneView.scene.rootNode.addChildNode(self.QuestionAR[self.QuestionAR.count - 1])
                 self.sceneView.autoenablesDefaultLighting = true  */
                
            }
        }
        
        let zoneIce = ProximityZone(tag: "Ice", range: ProximityRange(desiredMeanTriggerDistance: 1.0)!)
        if  !self.arrBeacon[1]  {
            zoneIce.onEnter = { contexts in
                print ("Ice zone")
                self.flagIce2 = true
                // self.displayQObj()
                self.flagIce = true
                
                
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let QuestViewController = storyBoard.instantiateViewController(withIdentifier: "questScene") as! QuestViewController
                self.present(QuestViewController, animated: true, completion: nil)
                
                /*      let text = SCNText(string: "?", extrusionDepth: 0.1)
                 let material = SCNMaterial()
                 material.diffuse.contents = UIColor.orange
                 text.materials = [material]
                 text.font = UIFont(name: "Avenir", size: 100)
                 
                 let planeNode4 = SCNNode()
                 planeNode4.position = SCNVector3(0, 0 , 0)
                 planeNode4.scale = SCNVector3(0.001, 0.001, 0.001)
                 planeNode4.geometry = text
                 planeNode4.runAction(self.fadeAndSpinAction)
                 self.QuestionAR.append(planeNode4)
                 let scene = SCNScene()
                 planeNode4.camera = SCNCamera()
                 self.sceneView.scene.rootNode.addChildNode(self.QuestionAR[self.QuestionAR.count - 1])
                 self.sceneView.autoenablesDefaultLighting = true  */
            }
        }
        
        let zoneBlueberry = ProximityZone(tag: "Blueberry", range: ProximityRange(desiredMeanTriggerDistance: 1.0)!)
        if  !self.arrBeacon[0]  {
            zoneBlueberry.onEnter = { contexts in
                print ("Blueberry zone")
                self.flagBlueBerry2 = true
                //     self.displayQObj()
                self.flagBlueBerry = true
                
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let PuzzleViewController = storyBoard.instantiateViewController(withIdentifier: "PuzzleStoryBoard") as! PuzzleViewController
                
                self.present(PuzzleViewController, animated: true, completion: nil)
                /*          let text = SCNText(string: "?", extrusionDepth: 0.1)
                 let material = SCNMaterial()
                 material.diffuse.contents = UIColor.orange
                 text.materials = [material]
                 text.font = UIFont(name: "Avenir", size: 100)
                 
                 let planeNode4 = SCNNode()
                 planeNode4.position = SCNVector3(0, 0 , 0)
                 planeNode4.scale = SCNVector3(0.001, 0.001, 0.001)
                 planeNode4.geometry = text
                 planeNode4.runAction(self.fadeAndSpinAction)
                 self.QuestionAR.append(planeNode4)
                 let scene = SCNScene()
                 planeNode4.camera = SCNCamera()
                 self.sceneView.scene.rootNode.addChildNode(self.QuestionAR[self.QuestionAR.count - 1])
                 self.sceneView.autoenablesDefaultLighting = true */
            }
        }
        let zonecouconet = ProximityZone(tag: "Coconut", range: ProximityRange(desiredMeanTriggerDistance: 1.0)!)
        if  !self.arrBeacon[3]  {
            zonecouconet.onEnter = { contexts in
                print ("Coconut zone")
                self.flagCoconut2 = true
                //  self.displayQObj()
                self.flagCoconut = true
                
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let MarksViewController = storyBoard.instantiateViewController(withIdentifier: "MarksStoryBoard") as! MarksViewController
                self.present(MarksViewController, animated: true, completion: nil)
                
                
                
                /*         let text = SCNText(string: "?", extrusionDepth: 0.1)
                 let material = SCNMaterial()
                 material.diffuse.contents = UIColor.orange
                 text.materials = [material]
                 text.font = UIFont(name: "Avenir", size: 100)
                 
                 let planeNode4 = SCNNode()
                 planeNode4.position = SCNVector3(0, 0 , 0)
                 planeNode4.scale = SCNVector3(0.001, 0.001, 0.001)
                 planeNode4.geometry = text
                 planeNode4.runAction(self.fadeAndSpinAction)
                 self.QuestionAR.append(planeNode4)
                 let scene = SCNScene()
                 planeNode4.camera = SCNCamera()
                 self.sceneView.scene.rootNode.addChildNode(self.QuestionAR[self.QuestionAR.count - 1])
                 self.sceneView.autoenablesDefaultLighting = true */
            }
        }
        
        self.proximityObserver.startObserving([zoneMint, zoneIce, zoneBlueberry, zonecouconet])
    }
    override func viewDidLoad() {  DispatchQueue.main.async {
        super.viewDidLoad()
        /// Display user score
        
        self.updateRewards()
        // beacon
        self.displayBeacon()
        
        
        }
        
        
        
        
        
        
    }
    
    
    func displayQObj(){
        
        
        let text = SCNText(string: "?", extrusionDepth: 0.1)
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.orange
        text.materials = [material]
        text.font = UIFont(name: "Avenir", size: 50)
        /*
         planeNode4 = SCNNode()
         planeNode4.position = SCNVector3(0, 0 , 0)
         planeNode4.scale = SCNVector3(0.001, 0.001, 0.001)
         planeNode4.geometry = text
         planeNode4.runAction(self.fadeAndSpinAction)
         let scene = SCNScene()
         planeNode4.camera = SCNCamera()
         sceneView.scene.rootNode.addChildNode(planeNode4)
         sceneView.autoenablesDefaultLighting = true*/
        //   self.sceneView.scene = scene
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let configuration = ARWorldTrackingConfiguration()
        
        sceneView.session.run(configuration)
        
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }
    
    
}
