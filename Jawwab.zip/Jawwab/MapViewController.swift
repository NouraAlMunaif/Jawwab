//
//  MapViewController.swift
//  Jawwab
//
//  Created by Latif Ath on 2/13/19.
//  Copyright © 2019 atheer. All rights reserved.
//

import UIKit
import Firebase

// SetStatus
protocol MapDelegate {
    func setStatus(q: Int)
}

class MapViewController: UIViewController {
    
    var ref: DatabaseReference!
    var userId = UserDefaults.standard.object(forKey: "userId") as? String
    
    
    var status: Dictionary = [String: String]()
    var Lstatus: Dictionary = [String: String]()
    
    @IBOutlet weak var q1: UIButton!
    @IBOutlet weak var q2: UIButton!
    @IBOutlet weak var q3: UIButton!
    @IBOutlet weak var L1: UIButton!
    @IBOutlet weak var q4: UIButton!
    
   
    var i = 1
    
    var emptyDict: [Int: String] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    
        ref = Database.database().reference();
        let qustions = ref.child("tour").child(userId!)
        qustions.observe(DataEventType.value, with: { (snapshot) in
            
            if !snapshot.exists() { return }
            let getData = snapshot.value as? [String : AnyObject]
            
            let q1 = getData!["q1"] as? Int
            let q2 = getData!["q2"] as? Int
            let q3 = getData!["q3"] as? Int
            let q4 = getData!["q4"] as? Int
            let c = getData!["current"] as? Int
            
            // update qustions
            self.solveChalanges(qNum: 1, qStatus: q1!)
            self.solveChalanges(qNum: 2, qStatus: q2!)
            self.solveChalanges(qNum: 3, qStatus: q3!)
            self.solveChalanges(qNum: 4, qStatus: q4!)
           
            self.setCurrent(qNum: c!)
           // update level
            if(q1 == 1 && q2 == 1 && q3 == 1 && q4 == 1){
                self.updateLevel(level: 1)
            }
            
           
            
        })
        
    
    }

    @IBAction func close(_ sender: Any) {
        
        dismiss(animated: true)
    }
    
    
    func setCurrent(qNum: Int){
        
        switch qNum {
            
        case 1:
              q1.setBackgroundImage(UIImage(named: "current" ), for: UIControl.State.normal)
        case 2:
              q2.setBackgroundImage(UIImage(named: "current" ), for: UIControl.State.normal)
        case 3:
              q3.setBackgroundImage(UIImage(named: "current" ), for: UIControl.State.normal)
        case 4:
              q4.setBackgroundImage(UIImage(named: "current" ), for: UIControl.State.normal)
            
        default:
            print("Some other character")
        }
        
    }
    
    func solveChalanges(qNum: Int, qStatus: Int){
        
        
       
            // update here
            switch qNum {
            
            case 1:
                 if(qStatus == 1){
                q1.setBackgroundImage(UIImage(named: "solved" ), for: UIControl.State.normal)
                }
                 else {
                q1.setBackgroundImage(UIImage(named: "qnot" ), for: UIControl.State.normal)
                }
            case 2:
                if(qStatus == 1){
                    q2.setBackgroundImage(UIImage(named: "solved" ), for: UIControl.State.normal)
                }
                else {
                    q2.setBackgroundImage(UIImage(named: "qnot" ), for: UIControl.State.normal)
                }
            case 3:
                if(qStatus == 1){
                    q3.setBackgroundImage(UIImage(named: "solved" ), for: UIControl.State.normal)
                }
                else {
                    q3.setBackgroundImage(UIImage(named: "qnot" ), for: UIControl.State.normal)
                }
            case 4:
                if(qStatus == 1){
                    q4.setBackgroundImage(UIImage(named: "solved" ), for: UIControl.State.normal)
                }
                else {
                    q4.setBackgroundImage(UIImage(named: "qnot" ), for: UIControl.State.normal)
                }

            default:
                print("Some other character")
            }
        


        
    }
    
    func updateLevel(level: Int){
        
        
        if(level == 1){
            L1.setBackgroundImage(UIImage(named: "levelSolved" ), for: UIControl.State.normal)
        }
        
        if(level == 2){
          //  Lstatus["l2"] = "levelSolved"
        }
        
    }
    
}


