//
//  profile.swift
//  Jawwab
//
//  Created by Nouf on 2/23/19.
//  Copyright © 2019 atheer. All rights reserved.
//

import Foundation
class profile{
    var username: String?
    var score: String?
    
    
    
    init(username: String?, score: String?){
        if(username != "u"){
            self.username=username}
        
        if(score != "s"){
            self.score=score}
    }
}


