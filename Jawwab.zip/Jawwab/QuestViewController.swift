//
//  QuestViewController.swift
//  Jawwab
//
//  Created by Noura Almunaif on 28/01/2019.
//  Copyright © 2019 atheer. All rights reserved.
//

import UIKit
import SceneKit
import ARKit
import EstimoteProximitySDK
import Firebase

// For generating random numbers


@available(iOS 12.0, *)
class QuestViewController: UIViewController, UITextFieldDelegate {
    var player: AVAudioPlayer?
    var proximityObserver: ProximityObserver! // Beacon declaration
    var ref: DatabaseReference!
    let userId = UserDefaults.standard.object(forKey: "userId") as? String
    @IBOutlet weak var sceneView: ARSCNView!
    
    @IBOutlet weak var label: UILabel!
    
    @IBOutlet weak var reward: UILabel!
    let fadeDuration: TimeInterval = 0.3
    let rotateDuration: TimeInterval = 3
    let waitDuration: TimeInterval = 0.5
    
    lazy var fadeAndSpinAction: SCNAction = {
        return .sequence([
            .fadeIn(duration: fadeDuration),
            .rotateBy(x: 0, y: 0, z: CGFloat.pi * 360 / 180, duration: rotateDuration),
            .wait(duration: waitDuration)
            // .fadeOut(duration: fadeDuration)
            ])
    }()
    
    lazy var fadeAction: SCNAction = {
        return .sequence([
            .fadeOpacity(by: 0.8, duration: fadeDuration),
            .wait(duration: waitDuration),
            //   .fadeOut(duration: fadeDuration)
            ])
    }()
    
    
    lazy var bookNode: SCNNode = {
        guard let scene = SCNScene(named: "art.scnassets/book.scn"),
            let node = scene.rootNode.childNode(withName: "book", recursively: true) else { return SCNNode() }
        let scaleFactor  = 0.1
        node.scale = SCNVector3(scaleFactor, scaleFactor, scaleFactor)
        return node
    }()
    
    
    func createLineNode(fromPos origin: SCNVector3, toPos destination: SCNVector3, color: UIColor) -> SCNNode {
        let line = lineFrom(vector: origin, toVector: destination)
        let lineNode = SCNNode(geometry: line)
        let planeMaterial = SCNMaterial()
        planeMaterial.diffuse.contents = color
        line.materials = [planeMaterial]
        
        return lineNode
    }
    
    func lineFrom(vector vector1: SCNVector3, toVector vector2: SCNVector3) -> SCNGeometry {
        let indices: [Int32] = [0, 1]
        
        let source = SCNGeometrySource(vertices: [vector1, vector2])
        let element = SCNGeometryElement(indices: indices, primitiveType: .line)
        
        return SCNGeometry(sources: [source], elements: [element])
    }
    
    
    func highlightNode(_ node: SCNNode) {
        let (min, max) = node.boundingBox
        let zCoord = node.position.z
        let topLeft = SCNVector3Make(min.x, max.y, zCoord)
        let bottomLeft = SCNVector3Make(min.x, min.y, zCoord)
        let topRight = SCNVector3Make(max.x, max.y, zCoord)
        let bottomRight = SCNVector3Make(max.x, min.y, zCoord)
        
        
        let bottomSide = createLineNode(fromPos: bottomLeft, toPos: bottomRight, color: .yellow)
        let leftSide = createLineNode(fromPos: bottomLeft, toPos: topLeft, color: .yellow)
        let rightSide = createLineNode(fromPos: bottomRight, toPos: topRight, color: .yellow)
        let topSide = createLineNode(fromPos: topLeft, toPos: topRight, color: .yellow)
        
        [bottomSide, leftSide, rightSide, topSide].forEach {
            //   $0.name = kHighlightingNode // Whatever name you want so you can unhighlight later if needed
            node.addChildNode($0)
        }
    }

    func playSound(fileName: String) {
        
        guard let url = Bundle.main.url(forResource: fileName, withExtension: "mp3") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
            
            
            guard let player = player else { return }
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
        
    }
    
    func updateRewards(){
        
        ref = Database.database().reference();
        
        
        let userscore = ref.child("users").child(userId!).child("UserScore")
        userscore.observeSingleEvent(of: .value, with: { (snapshot) in
            
            if let score = snapshot.value as? String{
                let score1 = Int(score)
                print(score1!)
                self.passingScore(score1: score1!)
            }
        })
        
        
    }
    
    
    func passingScore(score1: Int){
        ref = Database.database().reference();
        let score2 = String(score1);
        ref.child("users").child(userId!).child("UserScore").setValue(score2)
        //let score2 = String(score1);
        reward.text = score2
    }
    
    
    override func viewDidLoad() {  DispatchQueue.main.async {
        super.viewDidLoad()
        //   label.layer.backgroundColor  = UIColor.white.cgColor
        self.label.layer.masksToBounds = true
        self.label.layer.cornerRadius = 15
        
         self.playSound(fileName: "popUp")
        
        self.sceneView.delegate = self as ARSCNViewDelegate
        self.configureLighting()
        self.updateRewards()
 /*       let estimoteCloudCredentials = CloudCredentials(appID: "reem-badr-s-proximity-for--6o4", appToken: "8be2dff5dc16b9747b7fafe97ff53708")
        
        self.proximityObserver = ProximityObserver(credentials: estimoteCloudCredentials, onError: { error in
            print("ProximityObserver error: \(error)")
            
            
        })
        
        let zone = ProximityZone(tag: "reem-badr-s-proximity-for--6o4", range: ProximityRange.near)
        zone.onExit = { contexts in
            print("Exit in quest view controller")
            
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let Question1ViewController = storyBoard.instantiateViewController(withIdentifier: "mainView") as! Question1ViewController
            
            self.present(Question1ViewController, animated: true, completion: nil)
        }
        
        self.proximityObserver.startObserving([zone]) */
        
        
        
     
        }
    }
    func configureLighting() {
        sceneView.autoenablesDefaultLighting = true
        sceneView.automaticallyUpdatesLighting = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        resetTrackingConfiguration()
    }
    
    //   override func viewWillDisappear(_ animated: Bool) {
    //       super.viewWillDisappear(animated)
    //       sceneView.session.pause()
    //   }
    
    
    func resetTrackingConfiguration() {
        guard let referenceImages = ARReferenceImage.referenceImages(inGroupNamed: "AR Resources", bundle: nil)
            else {
                print("No image detected");
                return }
        let configuration = ARWorldTrackingConfiguration()
        configuration.detectionImages = referenceImages
        let options: ARSession.RunOptions = [.resetTracking, .removeExistingAnchors]
        sceneView.session.run(configuration, options: options)
        //  label.text = "Move camera around to detect images"
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first as! UITouch
        if(touch.view == self.sceneView){
            print("touch working")
            let viewTouchLocation:CGPoint = touch.location(in: sceneView)
            guard let result = sceneView.hitTest(viewTouchLocation, options: nil).first else {
                return
            }
            //   let imageName = imageAnchor.referenceImage.name
            let overlayNode = self.getNode(withImageName: "Book")
            if (overlayNode.contains(result.node)) { //to ensure which 3d object was touched
                print("match")
                // add a tap gesture recognizer
               let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
                sceneView.addGestureRecognizer(tapGesture)
                
                        for view in self.view.subviews {
                             view.removeFromSuperview()
                
                
                       }
                solveChallange(q: 2, status: 1)
                setCurrent(q: 2)
                
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let SuccessMessagesViewController = storyBoard.instantiateViewController(withIdentifier: "QMessage") as! SuccessMessagesViewController
                
                self.present(SuccessMessagesViewController, animated: true, completion: nil)
                
            }
            
        }
        
    }
    @objc
    func handleTap(_ gestureRecognize: UIGestureRecognizer) {
        // retrieve the SCNView
     //   let scnView = self.view as! SCNView
        
        // check what nodes are tapped
        let p = gestureRecognize.location(in: sceneView)
        let hitResults = sceneView.hitTest(p, options: [:])
        // check that we clicked on at least one object
        if hitResults.count > 0 {
            // retrieved the first clicked object
            let result = hitResults[0]
            
            // get its material
            let material = result.node.geometry!.firstMaterial!
            
            // highlight it
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0.5
            
            // on completion - unhighlight
            SCNTransaction.completionBlock = {
                SCNTransaction.begin()
                SCNTransaction.animationDuration = 0.5
                
                material.emission.contents = UIColor.black
                
                SCNTransaction.commit()
            }
            
            material.emission.contents = UIColor.red
            
            
            SCNTransaction.commit()
        }
    }
    
    
    func initChallange(q: Int){
        ref = Database.database().reference();
        var userId = UserDefaults.standard.object(forKey: "userId") as? String
        // 0 ==> not solved  || 1 ==> solved
        self.ref.child("tour").child(userId!).child("q\(q)").setValue(0)
        
    }
    
    func solveChallange(q: Int, status: Int){
        ref = Database.database().reference();
        var userId = UserDefaults.standard.object(forKey: "userId") as? String
        // 0 ==> not solved  // 1 ==> solved
        self.ref.child("tour").child(userId!).updateChildValues(["q\(q)": status])
        
    }
    
    func setCurrent(q: Int){
        ref = Database.database().reference();
        var userId = UserDefaults.standard.object(forKey: "userId") as? String
        self.ref.child("tour").child(userId!).updateChildValues(["current": q])
        
        
    }
   
}

@available(iOS 12.0, *)
extension QuestViewController: ARSCNViewDelegate {
    
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        DispatchQueue.main.async {
            guard let imageAnchor = anchor as? ARImageAnchor,
                let imageName = imageAnchor.referenceImage.name else { return }
           
            let overlayNode = self.getNode(withImageName: imageName)
            overlayNode.opacity = 0
            overlayNode.position.y = 0.2
            overlayNode.runAction(self.fadeAndSpinAction)
            node.addChildNode(overlayNode)
            //   let planeScene = SCNScene(named: "art.scnassets/book.scn")!
            /*          let planeNode = planeScene.rootNode.childNode(withName: "book", recursively: true)!
             // 2. Calculate size based on planeNode's bounding box.
             let (min, max) = planeNode.boundingBox
             let size = SCNVector3Make(max.x - min.x, max.y - min.y, max.z - min.z)
             
             
             // Ignore Y axis because it will be pointed out of the image.
             let widthRatio = Float(imageAnchor.referenceImage.physicalSize.width)/size.x
             let heightRatio = Float(imageAnchor.referenceImage.physicalSize.height)/size.z
             // Pick smallest value to be sure that object fits into the image.
             let finalRatio = [widthRatio, heightRatio].min()!
             // 5. Animate appearance by scaling model from 0 to previously calculated value.
             let appearanceAction = SCNAction.scale(to: CGFloat(0.1), duration: 0.4)
             appearanceAction.timingMode = .easeOut
             // Set initial scale to 0.
             planeNode.scale = SCNVector3Make(0.001, 0.001, 0.001)
             // Add to root node.
             self.sceneView.scene.rootNode.addChildNode(planeNode)
             // Run the appearance animation.
             planeNode.runAction(appearanceAction)*/
            // Add to root node.
        }
    }
    
    
    
    
    func getPlaneNode(withReferenceImage image: ARReferenceImage) -> SCNNode {
        let plane = SCNPlane(width: image.physicalSize.width,
                             height: image.physicalSize.height)
        let node = SCNNode(geometry: plane)
        return node
    }
    
    func getNode(withImageName name: String) -> SCNNode {
        var node = SCNNode()
        switch name {
        case "Book":
            node = bookNode
        default:
            break
        }
        return node
    }
    
    
    
}

