//
//  HomePageViewController.swift
//  Jawwab
//
//  Created by atheer on 1/24/19.
//  Copyright © 2019 atheer. All rights reserved.
//

import UIKit


class HomePageViewController: UIViewController {
    
    
 //   @IBOutlet weak var myAR: ARSCNView!
    
  //  let config = ARWorldTrackingConfiguration()

    override func viewDidLoad() {
        super.viewDidLoad()
        
     //   myAR.debugOptions = [ARSCNDebugOptions.showFeaturePoints, ARSCNDebugOptions.showWorldOrigin]
        
     //   myAR.session.run(config)

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

   

}
