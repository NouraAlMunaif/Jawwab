//
//  MarksViewController.swift
//  Jawwab
//
//  Created by Nora Almunaif on 05/06/1440 AH.
//  Copyright © 1440 atheer. All rights reserved.
//

import UIKit
import SceneKit
import ARKit
import Firebase
import EstimoteProximitySDK

class MarksViewController: UIViewController  {

    var Marks = [String]()
    var x : Float = 1
    var y : Float = 1
    @IBOutlet weak var sceneView: ARSCNView!
    var proximityObserver: ProximityObserver!
    let userId = UserDefaults.standard.object(forKey: "userId") as? String
    @IBOutlet weak var msg1: UITextField!
    
    @IBOutlet weak var reward: UILabel!
    @IBOutlet weak var sendIcon: UIButton!
    
    let fadeDuration: TimeInterval = 0.3
    let rotateDuration: TimeInterval = 3
    let waitDuration: TimeInterval = 0.5
    var ref: DatabaseReference!
    var flaggedNode = [SCNNode]()
    var flaggedtext = [SCNText]()
    var flaggedDescription = [String]()
    var key = [String]()
    var clicked = [Bool]()
    var flagCounter = 0
    var flagN = 0
    var i = 0
    
 //   var obj = [flagMark]()
    
    lazy var fadeAndSpinAction: SCNAction = {
        return .sequence([
            .fadeIn(duration: fadeDuration),
            .rotateBy(x: 0, y: 0, z: 0, duration: rotateDuration),
            .wait(duration: waitDuration)
            // .fadeOut(duration: fadeDuration)
            ])
    }()
    
    lazy var fadeAction: SCNAction = {
        return .sequence([
            .fadeOpacity(by: 0.8, duration: fadeDuration),
            .wait(duration: waitDuration),
            //   .fadeOut(duration: fadeDuration)
            ])
    }()
    
    func updateRewards(){
        
        ref = Database.database().reference();
        
        
        let userscore = ref.child("users").child(userId!).child("UserScore")
        userscore.observeSingleEvent(of: .value, with: { (snapshot) in
            
            if let score = snapshot.value as? String{
                let score1 = Int(score)
                print(score1!)
                self.passingScore(score1: score1!)
            }
        })
        
        
    }
    
    
    func passingScore(score1: Int){
        ref = Database.database().reference();
        let score2 = String(score1);
        ref.child("users").child(userId!).child("UserScore").setValue(score2)
        //let score2 = String(score1);
        reward.text = score2
    }
    
   
    
    
    @IBAction func addMark(_ sender: Any) {
        print("enter click")
        
        if(msg1.text?.isEmpty == false){
            if (msg1.text != "") {
                
                
                
                ref = Database.database().reference();
                let markID = Database.database().reference().childByAutoId().key
           //     ref.child("Marks").child(markID).child("name").setValue("passing variable")
                ref.child("Marks").child(markID).child("text").setValue(self.msg1.text)
                ref.child("Marks").child(markID).child("flag").setValue(0)
                ref.child("Marks").child(markID).child("markID").setValue(markID)
                print("marks added successfully ")
                
                
               
             //   self.Marks.append(markID)
                self.key.append(markID)
                self.clicked.append(false)
                self.Marks.append(self.msg1.text!)
                self.i = self.i + 1
                print ("i: ", i)
                let j = i - 1
                let node = self.getMark(withIndex: j)
                
                
                self.sceneView.scene.rootNode.addChildNode(node)
                self.sceneView.autoenablesDefaultLighting = true
                
                 self.msg1.text = ""
                
            }
        }
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first as! UITouch
        if(touch.view == self.sceneView){
            print("touch working")
            let viewTouchLocation:CGPoint = touch.location(in: sceneView)
            guard let result = sceneView.hitTest(viewTouchLocation, options: nil).first else {
                return
            }
            
           
            let location = touch.location(in: self.view)
            print(location)
       
            if (flaggedNode.contains(result.node)) {
                    print(result.node.description)
                var v = 0
                var flag = 0
                var temp = false
                if !temp {
                while v<flaggedDescription.count {
                    flagN = 0
                    flag = 0
                    if (flaggedDescription[v].isEqual(result.node.description)) {
                        print("match")
                        flagN = 0
                        flag = 0
                        if !clicked[v] {
                        print ("before: ", flagN)
                        ref = Database.database().reference();
                        let index = v
                        let mark = self.ref.child("Marks").child(key[v]);
                        mark.observe(DataEventType.value, with: { (snapshot) in
                            if !snapshot.exists() {
                                print ("error")
                                return
                            }
                            let postDict = snapshot.value as? [String : AnyObject]
                            flag = postDict?["flag"] as! Int
                            self.flagN = flag
                            print ("inside: ", flag)
                            print ("flag: ", flag)
                            self.flagN = flag
                            if !temp {
                            self.flaggedMark(numOfFlagged: self.flagN+1, index: index)
                            }
                            temp = true
                            print ("temp = true")
                           
                          })
                     
                    }
                    }
                    
                    v = v + 1
                  }
                }
                
              
                let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
                sceneView.addGestureRecognizer(tapGesture)
                
              
            }
            
            print ("outside")
            
        }
        
    }
    
    
    func flaggedMark(numOfFlagged: Int, index: Int){
        ref = Database.database().reference();
        print("after: ", flagN)
        if numOfFlagged == 3 {
            ref.child("Marks").child(key[index]).removeValue()
        }
            
        else{
            ref.child("Marks").child(key[index]).child("flag").setValue(numOfFlagged)
        }
    }
    @objc
    func handleTap(_ gestureRecognize: UIGestureRecognizer) {
      
        let p = gestureRecognize.location(in: sceneView)
        let hitResults = sceneView.hitTest(p, options: [:])
        
        if hitResults.count > 0 {
            
            let result = hitResults[0]
            
            let material = result.node.geometry!.firstMaterial!
            
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0.5
            
            
            SCNTransaction.completionBlock = {
                SCNTransaction.begin()
                SCNTransaction.animationDuration = 0.5
                
                material.emission.contents = UIColor.black
                
                SCNTransaction.commit()
            }
            var v = 0
            while v<flaggedDescription.count {
                
                if (flaggedDescription[v].isEqual(result.node.description)) {
                    material.emission.contents = UIColor.red
                }
                v = v + 1
            }
            
            
            SCNTransaction.commit()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.sceneView.delegate = self as? ARSCNViewDelegate
        self.view.bringSubviewToFront(sendIcon)
        
        let tap:UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(DismissKey))
        self.updateRewards()
        view.addGestureRecognizer(tap)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        
       
        sceneView.showsStatistics = false
        
        self.configureLighting()
        
        let credentials = CloudCredentials(appID: "jawwab-s-your-own-app-lu3", appToken: "156e99a87189f9a6c4baf33f0268d425")
        
        self.proximityObserver = ProximityObserver(credentials: credentials, onError: { error in
            print("ProximityObserver error: \(error)")
        })
       
        
        let zonecouconet = ProximityZone(tag: "Coconut", range: ProximityRange(desiredMeanTriggerDistance: 0.8)!)
            zonecouconet.onExit = { contexts in
                print ("Exit from Coconut")
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let Question1ViewController = storyBoard.instantiateViewController(withIdentifier: "mainView") as! Question1ViewController
                
                self.present(Question1ViewController, animated: true, completion: nil)
        }
        
        self.proximityObserver.startObserving([zonecouconet])
        
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= keyboardSize.height
            }
        }
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
    @objc func DismissKey(){
        view.endEditing(true)
    }
    
    func configureLighting() {
        sceneView.autoenablesDefaultLighting = true
        sceneView.automaticallyUpdatesLighting = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        resetTrackingConfiguration()
    }
    
    func resetTrackingConfiguration() {
        guard let referenceImages = ARReferenceImage.referenceImages(inGroupNamed: "AR Resources", bundle: nil)
            else {
                print("No image detected");
                return }
        let configuration = ARWorldTrackingConfiguration()
        configuration.detectionImages = referenceImages
        let options: ARSession.RunOptions = [.resetTracking, .removeExistingAnchors]
        sceneView.session.run(configuration, options: options)
    }

}

@available(iOS 12.0, *)
extension MarksViewController: ARSCNViewDelegate {
    
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        DispatchQueue.main.async {
            guard let imageAnchor = anchor as? ARImageAnchor,
                let _ = imageAnchor.referenceImage.name else { return }
          
            
            self.ref = Database.database().reference()
            var marks = [String]()
             var k = [String]()
            var n=0
            self.ref.child("Marks").observeSingleEvent(of: .value, with: { (snapshot) in
                if let result = snapshot.children.allObjects as? [DataSnapshot] {
                    marks.removeAll()
                    print ("array of marks: ", marks.count)
                    n=0
                    for child in result {
                        let snapshotValue = child.value as? NSDictionary
                        var text = snapshotValue?["text"] as? String
                        let ID = snapshotValue?["markID"] as? String
                        text = text! + " "
                        k.append(ID!)
                        marks.append(text!)
                        k[n] = (ID!)
                        marks[n] = (text!)
                        print( k[n])
                        print( marks[n])
                        n = n + 1
                    }
                    n=0
                    
                    self.Marks.removeAll()
                    
                    print ("array of Marks: ", self.Marks.count)
                    while n<marks.count {
                         self.clicked.append(false)
                         self.key.append(k[n])
                         print ("Key: ", k[n])
                         self.Marks.append(marks[n])
                        print ("Mark: ", marks[n])
                        
                        n = n + 1
                    }
                    
                    print("length of array:  ", self.Marks.count)
                 
                    
                    self.arraylength()
                    while self.i<self.Marks.count {
                        let node = self.getMark(withIndex: self.i)
                        
                        self.i = self.i + 1
                        self.sceneView.scene.rootNode.addChildNode(node)
                        self.sceneView.autoenablesDefaultLighting = true
                    }
                } else {
                    print("no results")
                }
            }) { (error) in
                print(error.localizedDescription)
            }
            print("out of loop:  ", self.Marks.count)
            
        }
    }
    
    
    func arraylength(){
        print("in arraylength function:  ", self.Marks.count)
    }
    

    
    func getMark(withIndex j: Int) -> SCNNode {
        print ("Marks[j]: ", Marks[j])
        var dis = false
        var text = SCNText(string: Marks[j], extrusionDepth: 0)
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.black
        text.materials = [material]
        text.font = UIFont(name: "Avenir", size: 10)
        
        let node = SCNNode()
    //    if (j%4 == 0){
            node.position = SCNVector3(0, x/60 , 0)
             x = 1 + x
   //     }
     //   else {
       //      node.position = SCNVector3(y/250, x/60 , 0)
         //   dis = true
         //   y = y + 1
    //    }
        node.scale = SCNVector3(0.001, 0.001, 0.001)
        node.geometry = text
        text = node.geometry as! SCNText
        
        let minVec = node.boundingBox.min
        let maxVec = node.boundingBox.max
        let bound = SCNVector3Make(maxVec.x - minVec.x,
                                   maxVec.y - minVec.y,
                                   maxVec.z - minVec.z);
        node.pivot = SCNMatrix4MakeTranslation(bound.x / 2,
                                               bound.y / 2,
                                               bound.z / 2)
        
        let image = UIImage(named: "flag")
        let planeNode4 = SCNNode(geometry: SCNPlane(width: 10, height: 10))
        planeNode4.geometry?.firstMaterial?.diffuse.contents = image
        planeNode4.position = SCNVector3(-4 , 7, 0)
        
        let plane = SCNPlane(width: CGFloat(bound.x + 27),
                             height: CGFloat(bound.y + 3))
        plane.cornerRadius = 5
        plane.firstMaterial?.diffuse.contents = UIColor.gray.withAlphaComponent(0.7)
        
        
        let planeNode = SCNNode(geometry: plane)
        planeNode.position = SCNVector3(CGFloat( minVec.x  ) + CGFloat(bound.x ) / 2 ,
                                        CGFloat( minVec.y ) + CGFloat(bound.y ) / 2,CGFloat(minVec.z - 0.01))
      
        
       
        
        node.addChildNode(planeNode)
        node.addChildNode(planeNode4)
        planeNode.name = "text"
       
     /*   if dis {
            y = Float(CGFloat( node.boundingBox.max.x  ) + CGFloat(node.boundingBox.min.x ))
            print ("bound.x: ", y)
        }*/
        flaggedDescription.append(planeNode4.description)
        
        flaggedNode.append(planeNode4)
        flaggedtext.append(text)
        flagCounter = flagCounter + 1
      return node
        
    }
    
    
    
}

